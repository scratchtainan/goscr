<?php

echo "PHP 123";

?>